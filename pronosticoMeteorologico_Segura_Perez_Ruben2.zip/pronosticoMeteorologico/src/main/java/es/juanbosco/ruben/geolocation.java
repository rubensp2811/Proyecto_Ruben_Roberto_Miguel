package es.juanbosco.ruben;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class geolocation {
    @JacksonXmlProperty(isAttribute = true)
    private double altitud;
    @JacksonXmlProperty(isAttribute = true)
    private double latitud;
    @JacksonXmlProperty(isAttribute = true)
    private double longitud;
    @JacksonXmlProperty(isAttribute = true)
    private String geobase;
    @JacksonXmlProperty(isAttribute = true)
    private int geobaseid;
}
