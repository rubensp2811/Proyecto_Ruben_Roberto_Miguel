package es.juanbosco.ruben.time.wind;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class windGust{
    @JacksonXmlProperty(isAttribute = true)
    private double gust;
    @JacksonXmlProperty(isAttribute = true)
    private String unit;
}