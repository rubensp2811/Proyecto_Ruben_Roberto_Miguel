package es.juanbosco.ruben;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import es.juanbosco.ruben.time.Time;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.File;
import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.Scanner;


public class Main {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        XmlMapper mapper = new XmlMapper();
        mapper.registerModule(new JavaTimeModule());
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

        Weather weather;
        try {
            weather = mapper.readValue(new File("forecast.xml"), Weather.class);
        } catch (IOException e) {
            System.err.println("Error al leer el archivo XML: " + e.getMessage());
            return;
        }

        boolean salir = false;
        while (!salir) {
            System.out.println("\n=== MENÚ ===");
            System.out.println("1. Verificar temperaturas");
            System.out.println("2. Mostrar previsión próximos 5 días con iconos");
            System.out.println("3. Filtrar previsiones próximas 24 horas");
            System.out.println("4. Salir");
            System.out.print("Elige una opción: ");
            int opcion = sc.nextInt();

            switch (opcion) {
                case 1 -> verificarTemperaturas(weather);
                case 2 -> mostrarPrevision5Dias(weather);
                case 3 -> filtrar24Horas(weather);
                case 4 -> salir = true;
                default -> System.out.println("Opción inválida");
            }
        }

        sc.close();
    }


    private static void verificarTemperaturas(Weather weather) {
        for (Time t : weather.getForecast()) {
            double min = t.getTemperature().getMin();
            double max = t.getTemperature().getMax();
            double actual = t.getTemperature().getValue();

            if (min <= max) {
                if (actual >= min && actual <= max) {
                    System.out.println("Temperatura consistente: " + actual + "°C");
                } else {
                    System.out.println("⚠ Temperatura " + actual + " fuera del rango [" + min + ", " + max + "]");
                }
            } else {
                System.out.println("Error: temperatura mínima mayor que la máxima [" + min + " > " + max + "]");
            }
        }
    }


    private static void mostrarPrevision5Dias(Weather weather) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
        LocalDateTime ahora = LocalDateTime.now();
        LocalDateTime cincoDias = ahora.plusDays(5);

        for (Time t : weather.getForecast()) {
            if (t.getFrom().isAfter(ahora) && t.getFrom().isBefore(cincoDias)) {
                System.out.println(t.getFrom().format(formatter) + " | Temp: " + t.getTemperature().getValue() + "°C");
            }

        }
    }


    private static void filtrar24Horas(Weather weather) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
        LocalDateTime ahora = LocalDateTime.now();
        LocalDateTime manana = ahora.plusHours(24);


        for (Time t : weather.getForecast()) {
            if (t.getFrom().isAfter(ahora) && t.getFrom().isBefore(manana)) {
                System.out.println(t.getFrom().format(formatter) + " | Temp: " + t.getTemperature().getValue() + "°C");
            }
        }


    }

}
