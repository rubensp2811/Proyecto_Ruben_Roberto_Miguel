package es.juanbosco.ruben;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import es.juanbosco.ruben.time.Time;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
class Location{

            private String name;
            private String type;
            private String country;
            private int timezon;
            @JacksonXmlProperty (localName = "location")
            private geolocation geolocation;
        }

@Data
@AllArgsConstructor
@NoArgsConstructor
    class Meta {
        private LocalDate lastupdate;
        private int calctime;
        private LocalDate nextupdate;

    }

@Data
@AllArgsConstructor
@NoArgsConstructor
    class Sun {
        @JacksonXmlProperty(isAttribute = true)
        private LocalDateTime rise;
        @JacksonXmlProperty(isAttribute = true)
        private LocalDateTime set;

    }

@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class Weather {
    @JacksonXmlElementWrapper(localName = "forecast")
    @JacksonXmlProperty(localName = "time")
    private Time[] forecast;
}
