package es.juanbosco.ruben.time;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Humidity {
    @JacksonXmlProperty(isAttribute = true)
    private int value;
    @JacksonXmlProperty(isAttribute = true)
    private String unit;
}
