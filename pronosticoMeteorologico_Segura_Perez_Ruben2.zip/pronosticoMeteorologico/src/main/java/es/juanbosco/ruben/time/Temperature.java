package es.juanbosco.ruben.time;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Temperature {
    @JacksonXmlProperty(isAttribute = true, localName = "unit")
        private String unit;
    @JacksonXmlProperty(isAttribute = true, localName = "value")
    private double value;
    @JacksonXmlProperty(isAttribute = true, localName = "min")
    private double min;
    @JacksonXmlProperty(isAttribute = true, localName = "max")
    private double max;
}